<?php
define("DBHOST", "localhost");//:
define("DBUSER", "root");
define("DBPASS","");
define("DBNAME","swproject");
$con = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME); 
if(!$con)
{
   echo"error";
}
else
{
   $star = $_POST["star"]; 
   $review = $_POST["review"]; 
   $name = $_POST["name"];   
   $id = $_POST["id"];
    
   $sql = "INSERT INTO `post` (`rate`, `review`, `name`, `id`) VALUES ('$star', '$review', '$name', '$id');";
   mysqli_query($con, $sql);
   if(mysqli_query($con, $sql))
   {
      echo "<script>window.location.href = 'CompanyFeed.php';</script>";
   }
   else 
   {
      echo "failed the request";
   }   
}
?>