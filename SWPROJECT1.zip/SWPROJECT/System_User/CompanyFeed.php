<?php
define("DBHOST", "localhost");//:
define("DBUSER", "root");
define("DBPASS","");
define("DBNAME","swproject");
$con = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
if(!$con)
{
echo"error";
}
    
 /*
  if(isset($_POST['submit'])) {
  //echo"";
  
  $star = mysqli_real_escape_string($con, $_POST['star']);
  $review = mysqli_real_escape_string($con, $_POST['review']);
  $name = mysqli_real_escape_string($con, $_POST['name']);
  $id = 2;

  $sql = "INSERT INTO `post` (`rate`, `review`, `name`, `id`) VALUES (`$star`, `$review`, `$name`, `$id`);";
  if(mysqli_query($con, $sql))
    {
        echo "sucsess";
    }
    else 
    {
        echo "failed the request";
    
    }  
}
*/

?>



<!DOCTYPE html>

<html lang="en"> <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css"> 
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<title> trainee’s guide</title>
​
​
<link rel="stylesheet" href="projectmenu.css">
<link rel="stylesheet" href="CompanyTRY2.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css'> 
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
    <body>
        <header>
			<nav>
				<img  class="logo" src="image/Picture1.png" alt="company logo" >
					<a href="CompanyFeed.php"> Feed</a>
					</nav>
        </header>
		 
		  <main>   
          
		
<br><br>
		
     <!-- Load icon library -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!-- The form -->
<form class="example" action="">
  <input text-align="center" type="text" placeholder="Search.." name="search">
  <button type="submit"><i class="fa fa-search"></i></button>
</form>

<div class="feed">



<?php 

	if(isset($_GET['search'])){
		$res = mysqli_query($con,"SELECT * FROM company WHERE name LIKE '%".$_GET['search']."%'");
	}else{
		$res = mysqli_query($con,"SELECT * FROM company");
	}
	while($row = mysqli_fetch_assoc($res)){
        
            
 ?>


<div class="company1">
  <img src="../System_Admin/image/<?php echo $row['image']; ?>" alt="ste logo" height="200" style="width:100%">
  <h1><?php echo $row['name']; ?></h1>
  <p class="title">we are a tech start-up our foucs is to provide new way of sloving problems<br> using AI technologies</p>
  <p>Riyadh,KSA</p>
  <a href="#"><i class="fa fa-dribbble"></i></a>
  <a href="#"><i class="fa fa-twitter"></i></a>
  <a href="#"><i class="fa fa-linkedin"></i></a>
  <a href="#"><i class="fa fa-facebook"></i></a>
  <section id="rating" >
	<div class="customer-feedback">
		<div class="container text-center">
			<div class="row">
				<div class="col-sm-offset-2 col-sm-8">
					<div>
						<h2 class="section-title">previous trainees' reviews</h2>
					</div>
				</div><!-- /End col -->
			</div><!-- /End row -->
  
			<div class="row">
				<div class="col-md-offset-3 col-md-6 col-sm-offset-2 col-sm-8">
					<div class="owl-carousel feedback-slider">

                                            <?php
                                                $num = 0;
                                                $sql2 = "SELECT * FROM post WHERE id =".$row['id'];
                                                $res2 = mysqli_query($con, $sql2);
                                                while ($row2 = mysqli_fetch_assoc($res2)) { 
                                                    $num++
                                            ?>
						<!-- slider item -->
						<div class="feedback-slider-item">
							
							<h3 class="customer-name"><?php echo $row2['name']; ?></h3>
							<p> <?php echo $row2['review']; ?></p>
							<span class="light-bg customer-rating" data-rating="5">
								<?php echo $row2['rate']; ?>/5
								<i class="fa fa-star"></i>
							</span>
						</div>
						<!-- /slider item -->
   <?php 
    } 
               if($num == 0)
                echo "<p style='font-weight:bold; font-size:1.3em;'> No reviews yet!</p>"; ?>
				

					</div><!-- /End feedback-slider -->

					<!-- side thumbnail -->
					<div class="feedback-slider-thumb hidden-xs">
						<div class="thumb-prev">
							
							<span class="light-bg customer-rating">
								5/5
								<i class="fa fa-star"></i>
							</span>
						</div>

						<div class="thumb-next">
							
							<span class="light-bg customer-rating">
								4/4
								<i class="fa fa-star"></i>
							</span>
						</div>
					</div>
					<!-- /side thumbnail -->

				</div><!-- /End col -->
			</div><!-- /End row -->
		</div><!-- /End container -->
	</div><!-- /End customer-feedback -->
	<br>
	<br>
         
	<div> <!-- rate and write review-->
		<h2 class="section-title">Rate and write about your experience!</h2>
		
		<div class="feedback-slider-item">
		
		<br><br><br>
                <form action="post.php" method="POST">
				<div class="stars">
					<input class="star star-5" id="star-5-<?php echo $row['id']; ?>" type="radio" name="star" value="5"/>
					<label class="star star-5" for="star-5-<?php echo $row['id']; ?>"></label>
					<input class="star star-4" id="star-4-<?php echo $row['id']; ?>" type="radio" name="star" value="4"/>
					<label class="star star-4" for="star-4-<?php echo $row['id']; ?>"></label>
					<input class="star star-3" id="star-3-<?php echo $row['id']; ?>" type="radio" name="star" value="3"/>
					<label class="star star-3" for="star-3-<?php echo $row['id']; ?>"></label>
					<input class="star star-2" id="star-2-<?php echo $row['id']; ?>" type="radio" name="star" value="2"/>
					<label class="star star-2" for="star-2-<?php echo $row['id']; ?>"></label>
					<input class="star star-1" id="star-1-<?php echo $row['id']; ?>" type="radio" name="star" value="1"/>
					<label class="star star-1" for="star-1-<?php echo $row['id']; ?>"></label>
				</div>
			
				<br>
				<textarea name="review" rows="8" placeholder="write your review here..."></textarea>
			
				<br><br>
				<input type="text" name="name" placeholder="write your name here...">
				
				<!--<input id="LinkasButton" type="submit" value="Post it!">-->
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <button type="submit" name="submit" id="LinkasButton" >Post it!
                    <!--<?php //echo '<a href="post.php?star=value&review=review&name=name&id='.$row['id'].'">'; ?> </a>-->
                </button>

			</form>
		</div>
	</div> <!-- /End rate and write review -->
</section>
 <a id="LinkasButton" href="JoinOurTeamF.html">Join our team!</a>
</div>

<?php } ?>

</div>
​
​
		 </main>
      
        <footer>
            <a href="">Support</a>
			<div class="text1">trainee’s guide</div>
        </footer>
    </body>
	<script>
	function ValidateEmail(input) {
​
  var validRegex = /^[a-zA-Z0-9.!#$%&'+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)$/;
​
  if (input.value.match(validRegex)) {
​
    alert("Valid email address!");
​
    document.form1.text1.focus();
​
    return true;
​
  } else {
​
    alert("Invalid email address!");
​
    document.form1.text1.focus();
​
    return false;
​
  }
​
}
</script>
</html>