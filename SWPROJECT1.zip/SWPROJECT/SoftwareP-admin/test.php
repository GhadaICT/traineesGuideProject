<?php

    function logIn($con,$role){
     
      if ($role=='admin')
           $userNumber= $_POST['Name'];

        $userPass= trim($_POST["password"]);

        if(!empty($userNumber)&&!empty($userPass)){
                          
                       if($role=='admin'){

                                $stmt = mysqli_prepare($con, "SELECT name,username,phonenumber,password FROM $role WHERE username=?");

                                mysqli_stmt_bind_param($stmt, "s", $userNumber);

                                mysqli_stmt_execute($stmt);

                                mysqli_stmt_bind_result($stmt, $reId,$UN,$P,$rePass);

                                mysqli_stmt_fetch($stmt);

                                if($UN!=$userNumber){

                                    $msg ="Invalid information user, Try again!";
                                    
                                }else{
                                    
                                    if(($userPass == $rePass)||password_verify($userPass, $rePass)){
                                        $msg="Welcome";
                                        echo '<script>alert("Welcome")</script>';
                                        $_SESSION['userId'] =$UN;
                                        $_SESSION['role'] =$role;
                                       
                                          if((($userPass == $rePass)||password_verify($userPass, $rePass))&&($UN==userNumber)){
                                            header("Location:  AddCompany.php");
                                                   }
                                  
                                    }else{
                                        $msg = "invalid information, Try again!";
                                    }
                                }                      
                    }
                    else {
                        $msg ="invalid user type, Try again!";
                  }
                }// something empty
       else {
            $msg = "something empty, Try again!";
       }

       
        
            
        return $msg;
        
    }
   
    

    
        function chick_home($con){
        if(isset($_SESSION['userId'])&&isset($_SESSION['role'])&&($_SESSION['role']=='admin')){
            $id = $_SESSION['userId'];
            $sqli = "SELECT * FROM admin WHERE username = '$id' limit 1";
            $resulti = mysqli_query($con,$sqli);
            if($resulti && mysqli_num_rows($resulti)>0){
                header("Location: AddCompany.php");
                return true;
            }
        }   
        //no such user go home
        //header("Location: index.php");// redirect to home page
    }
    
           function chick_login($con,$role){
        if(isset($_SESSION['userId'])&&isset($_SESSION['role'])){
            if($role=="admin"){
                if($role == $_SESSION['role']){
                        if(isset($_SESSION['userId'])){
                            $id = $_SESSION['userId'];
                            $sql = "SELECT * FROM $role WHERE username  = '$id' limit 1";
                            $result = mysqli_query($con,$sql);
                            if($result && mysqli_num_rows($result)>0){
                                return mysqli_fetch_assoc($result);
                            }
                        } 
                }
            }elseif ($role=="both") {
             $role= $_SESSION['role'];
                if(isset($_SESSION['userId'])){
                    $id = $_SESSION['userId'];
                    $sql = "SELECT * FROM $role WHERE username  = '$id' limit 1";
                    $result = mysqli_query($con,$sql);
                    if($result && mysqli_num_rows($result)>0){
                        return mysqli_fetch_assoc($result);
                    }
                } 
            }
        } 
        header("Location: login.php");
    }
    
    
?>