
<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
    define("DBHOST", "localhost");//:
    define("DBUSER", "root");
    define("DBPASS","root");
    define("DBNAME","swproject");

    
    /* Attempt to connect to MySQL database */
    $con = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
    
    // Check connection
    $error = mysqli_connect_error();
    if ($error != null){
        exit("ERROR: Could not connect. " . $error);//TODO *remove error msg*
    }
?>