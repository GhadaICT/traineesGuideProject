<?php
    #task 5
    session_start();
    session_start();
        include_once "config.php";
        include_once "test.php";
        $role ='admin';
        $res_data = chick_home($con);

        if($_SERVER['REQUEST_METHOD']=="POST"){   
               $log_error_msg = logIn($con,$role);

        }
?>



<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<title> trainee’s guide</title>



</head>
	<style>
		
/*remaz*//*remaz*//*remaz*/
/*remaz*//*remaz*//*remaz*/

@import url('https://fonts.googleapis.com/css2?family=Fahkwang:wght@200&family=Tenor+Sans&display=swap');

body{ height:100%;
	  max-width: 100%;
      margin: 0em auto;
	  background-color: #EFEFEF;
	  color: #000000;
	  font-family: 'Fahkwang', sans-serif;
    }

	
text1
	.container{
		padding: 0em 1.5em;
	}

	

	header{
		font-weight: bold;
		list-style-type: none;
		margin: 0em;
		padding: 0em;
		overflow: hidden;
		background-color: #98999A;
		height:65px;
	}
	
	footer{
		font-weight: bold;
		list-style-type: none;
		margin: 0em;
		padding: 0em;
		overflow: hidden;
		background-color: #98999A;
		height:40px;
	}

	.logo{
		display: block;
		float: left;
	    display: inline-block;
        padding: 0em 0em;
		padding-left: 1.5em;
height:4.5em;
width:4.5em;


	}
	
	.invoice-container{
		display: grid;
		grid-template-columns: 1fr;
		gap: 1.5em;
		padding: 1.5em 0em;
		margin: 0em;
	}
	
	/*navigation*/
	nav a {
		float: left;
		display: block;
		color: #000;
		text-align: center;
		padding: 14px 16px;
		margin: auto 1.5em;
		text-decoration: none;
	}
	nav a:hover{
		color: #000;
		text-decoration: none;
		
		
	}
	
	nav a:hover:not(.active) {
		background-color: #939799;
	}
	.active {	
		background-color: #606060;
		height:65px;
	}
	#home{
		margin-left:6em;
	}
	
	/*links*/
	footer a {
		color: #13293D;
		padding-left: 1.5em;
		padding-top: 1.5em;
		text-decoration: none;
	}
	
	
	
	li a {
		color: #225DA5;
		text-decoration: none;
		
	}
	
	
	
	

.dropdown-content {
	display: none;
	position: absolute;
	background-color: #f1f1f1;
	min-width: 190px;
	box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
	z-index: 1;
}

.dropdown-content a {
	color: black;
	padding: 12px 16px;
	text-decoration: none;
	display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
/*order button*/
#order{
	display: block;
	margin: 1.5% 26%;
}

/*the breadcrumbs*/
ul.breadcrumbs {
  padding: 0em;
  list-style: none;
  color: #000;
}
ul.breadcrumbs li {
  display: inline;
  font-size: 12px;
  color: black;
 
}
ul.breadcrumbs li+li:before {
  padding: 8px;
  color: black;
  content: "\276F";
}


@media screen and (min-width:992px) {
	.menu{
		font-size: 16px;
	}
	.menu-group{
		grid-template-columns: repeat(2,1fr);
	}
}

.text1 {
  background-color: white;
  color: black;
  font-size: 1vw;
  font-weight: bold;
  margin: 0 90%;
  padding: 7px;
  width: 9%;
  text-align: right;  
  left: 4%; 
  position: absolute;
  transform: translate(-50%, -50%); 
  mix-blend-mode: screen; 
}



/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

/* Set a style for all buttons */
button  {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  
}

button:hover {
  opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
  position: relative;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* The Modal (background) */
.modal {
  
  width: 50%; /* Full width */
  height: 70%; /* Full height */
   margin-right:20%;
   margin-left:20%;
  
  background-color:#DEDEDE;
  border:solid ;
}
.login{
	  color: black;
  font-size: 2vw;
  font-weight: bold;
	
}
/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button (x) */
.close {
  position: absolute;
  right: 25px;
  top: 0;
  color: #000;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: red;
  cursor: pointer;
}

/* Add Zoom Animation */
.animate {
  -webkit-animation: animatezoom 0.6s;
  animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
  from {-webkit-transform: scale(0)} 
  to {-webkit-transform: scale(1)}
}
  
@keyframes animatezoom {
  from {transform: scale(0)} 
  to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
.w3-section{
 padding-right: 10px;
  padding-left: 10px;
	}
	


/*remaz*//*remaz*//*remaz*/
/*remaz*//*remaz*//*remaz*/



     	</style>
    <body>
        <header>
            <nav>
			<img  class="logo" src="image/Picture1.png" alt="company logo" >
              
							
                </nav>
        </header>
		 
		  <main>   
            <div class="container">
			
                <ul class="breadcrumbs">
                   
                    <li>log in</li>
                  </ul>
		
		    </div>
		
               <!-- log in -->
			   <!--  remaz -->
			   <!-- log in -->
   
    <div class="modal" >
    <h4 id="login" ><b>Login </b></h4>
    <div class="w3-row-padding w3-center w3-padding-24" style="margin:0 -16px">
      <div class="imgcontainer">
      <img src="image/Picture1.png" alt="Avatar" class="avatar" width="220"style="">
      <div><p><?php echo $log_error_msg; ?></p></div>
    </div>
    </div>
	
    <hr class="w3-opacity">
	
	
    <form method="POST">
      <div class="w3-section">
        <label>UserName</label>
        <input class="w3-input w3-border" type="text" name="Name" required >
      </div>

	
	   
      <div class="w3-section">
        <label>password </label>
        <input class="w3-input w3-border" type="password" name="password" required>
      </div>

      <button type="submit" class="button" role="button" name="submit" value="LogIn">submit</button>
	  <div class="container signin">
    <p>not a member? <a href="signup.php">sign up</a> </p>
  </div>
    </form>
	 </div>
		<br>
		<br>

	


		 </main>
      
        <footer>
            <a href="">Support</a>
			<div class="text1">trainee’s guide</div>
        </footer>
    </body>
</html>






























