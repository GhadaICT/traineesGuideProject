<?php

 define("DBHOST", "localhost");//:
 define("DBUSER", "root");
 define("DBPASS","root");
 define("DBNAME","swproject");
 
 $con = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
 
 if(!$con){
    echo"error";
 }
 
 else {
     
    $id = $_GET['id']; 
     
    $sql = "DELETE FROM company WHERE id = '$id';";

    mysqli_query($con, $sql);
    
    if(mysqli_query($con, $sql))
    {
        header("Location: CompanyFeedAdmin.php");
    }
    else 
    {
        echo "failed the request";
    
    }   
 }
 
?>
