
//<?php
//    #task 4 
//    session_start();
//        //includes
//        include_once "config.php";
//        include_once "test.php";
//        //login chick
//        $role ="admin";
//        $res_data = chick_login($con,$role);
//        
//        if(isset($_SESSION['userId'])){
//        $id = $_SESSION['userId'];  } 
//?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

<link rel="stylesheet" href="projectmenu.css"> <!--<link rel="stylesheet" href="mainme.css">-->
    <title>Add Company</title>
</head>
<script>  
    function validateform(){  
    var Coname=document.myform.coName.value;  
    var email=document.myform.email.value;  
      var num = document.myform.phone.value;
      var file =  document.getElementById('file').value;
     // var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
    if (Coname==null || Coname==""){  
      alert("Name can't be blank");  
      return false;  
    }
    else if(email==null || email==""){  
      alert("Email can't be blank");  
      return false;  
      } else if(!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(myform.email.value))
  {
    alert("You have entered an invalid email address!")
    return (false)
  }
  else if (num==null || num=="")
  {
alert("phone number can't be blank")
return(false)
  }
  else if(!/^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$/.test(num))
        {
        alert("invalid phone number, it hat to be 10 number start with 05 ");
        return false;
        }
        else if (file==null || file=="")
        {
alert("you have to uploead a file")
return(false)
        }
        if (!/(\.jpg|\.jpeg|\.png|\.gif)$/i.exec(file)) {
                alert('Invalid file type, it has to be an image (png , jpg, gif, jpeg) ');
                return false;
            } 
  else
  {
      alert("your form is sent, thank you !!")
      return(true)
  }
  
}
    
    </script>  
<body>
    <header>
        <nav>
			<img  class="logo" src="image/Picture1.png" alt="company logo" >
                <a id="home" href="JoinOurTeamFAdmain.html">Join Our Team</a>
                <a href="AddCompany.php">Add new Company</a>
                <a href="CompanyFeedAdmin.php">Feed</a>
               <a href="logOut.php" accesskey="h"> Sign out </a>
              
                </nav>


    </header>
<style>
.container
{
position: relative;
right : -20%;
width: 700px;

}
fieldset{
border: solid thin;
box-shadow: 2px 2px 2px gray;
border-radius: 20px;
}
.apply
{
    background-color: rgb(49, 47, 47);
    
}
#FormTitle-deena
{
    background-color: rgb(0, 0, 0);
    color: aliceblue;
    border-radius: 20px;
    opacity: 0.5;
}
</style>
    <main>

        <div class="container">
        <form class="well form-horizontal" name="myform"  action=" " method="post"  id="_form" onsubmit="validateform()"> <!--Remove (return)-->
            <fieldset>
            
            <!-- Form Name -->
            <legend id="FormTitle-deena" >new companies new apportanties!</legend>
            
            <!-- Text input-->
            
            <div class="form-group">
              <label class="col-md-4 control-label">Company's Name</label>  
              <div class="col-md-4 inputGroupContainer">
              <div class="input-group">
              <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
              <input  name="coName" placeholder="Company's Name" class="form-control"  type="text"> <!---DONE-->
                </div>
              </div>
            </div>
            
            <br>
            
            <!-- Text input-->
                   <div class="form-group">
              <label class="col-md-4 control-label">Company's E-Mail</label>  
                <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
              <input name="email" placeholder="E-Mail Address" class="form-control"  type="text"> <!--mail-->
                </div>
              </div>
            </div>
            
            <br>
            
            <!-- number input-->
                   
            <div class="form-group">
              <label class="col-md-4 control-label">Phone #</label>  
                <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
              <input name="phone" placeholder="05XXXXXXX" class="form-control" type="text"> <!--PNAME-->
                </div>
              </div>
            </div>
            <br>
            
            <!-- Select Basic -->
               
            <div class="form-group"> 
              <label class="col-md-4 control-label">Company's Field</label>
                <div class="col-md-4 selectContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                <select name="GPA" class="form-control selectpicker" >
            
                  <option>Medicine</option>
                  <option>Information Technology</option>
                  <option>Humen Resources</option>
                  <option>Education </option>
                  <option>Finance</option>
                  <option>Marketing</option>
            
                 
                 
                </select>
              </div>
            </div>
            </div>
            <br>
            
        
              
            <div class="form-group">
              <label class="col-md-4 control-label">upload company's logo:</label>
              <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
            <input type="file" id="file" name="file">
            </div>
            </div>
            </div>
            
            <br>
            
            
            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label"></label>
              <div class="col-md-4">
                <button type="submit" class="apply">ADD<span class="glyphicon glyphicon-send"></span></button> <!--onclick="return validateForm()"-->
              </div>
            </div>
            
            </fieldset>
            </form>
            </div>

    </main>

    <footer>
        <a href="">Support</a>
        <div class="text1">trainee’s guide</div>
    </footer>
</body>
</html>
