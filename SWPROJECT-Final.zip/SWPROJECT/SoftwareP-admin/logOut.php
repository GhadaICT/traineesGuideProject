<?php
#task log out 
    session_start();
    //end session
    session_destroy();
    //go home
    header("Location: login.php");
 
    ?>
